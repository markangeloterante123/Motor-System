
  <!-- Left side column. contains the logo and sidebar -->
 

  <!-- Content Wrapper. Contains page content -->
  <div  class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        REPLACEMENT RECORDS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Replacment</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
            <div class="box box-info">
            <div class="box-header with-border">
              <div class="input-group">
                <input type="text" name="searchHistory" id="searchHistory" class="form-control" placeholder="Search...">
              </div>
            </div>
             
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>POS#</th>
                    <th>CUSTOMER'S NAME</th>
                    <th>ITEM</th>
                    <th>PARTS NO.</th>
                    <th>BRAND & DESCRIPTION</th>
                    <th>QTY</th>
                    <th>ACTION</th>
                  </tr>
                  </thead>
                  <tbody class="replacment">
                    
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
        
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

       <!--  <div class="col-md-4">  
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Item Stock</h3>
            </div>
            <div class="box-body ">
              <div class="newItems">
              </div>
            </div>
            <div class="box-footer text-center">
              <a href="<?php echo base_url(); ?>pages/pageAdmin/inventory" class="uppercase">View All Products</a>
            </div>
          </div>
        </div> -->
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


  